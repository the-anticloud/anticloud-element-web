# 21 Related Scientific Research

**Project:** ELEMENT_WEB
**Upstream:** https://github.com/vector-im/element-web

Content specific to ELEMENT_WEB in category CHAT_PLATFORMS.
