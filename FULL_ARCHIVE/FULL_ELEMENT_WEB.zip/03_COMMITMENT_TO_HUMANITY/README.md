# 03 Commitment To Humanity

**Project:** ELEMENT_WEB
**Upstream:** https://github.com/vector-im/element-web

Content specific to ELEMENT_WEB in category CHAT_PLATFORMS.
